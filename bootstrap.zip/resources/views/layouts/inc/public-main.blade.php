<!-- Main Content Start -->
<div class="main-content">
    @include('layouts.inc.public-main.home')

    @include('layouts.inc.public-main.about')

    @include('layouts.inc.public-main.service')

    @include('layouts.inc.public-main.portfolio')

    @include('layouts.inc.public-main.blog')

    @include('layouts.inc.public-main.contact')

</div>
<!-- Main Content End -->
