<?php $__env->startSection('title', 'larablog - Contact'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-3">
        <div class="card mt-4">
            <div class="card-header">
                <h4>Contact Infomation <a href="<?php echo e(route('public.index')); ?>" target="_blank"
                        class="btn btn-primary float-end">Live
                        View</a></h4>
            </div>
            <div class="card-body">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>ZamSh!</strong> <?php echo e(session('msg')); ?>

                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h5>View Messages</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive-md">
                            <table id="datatablesSimple">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Message</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                                <tbody>

                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->subject); ?></td>
                                            <td><?php echo e($item->message); ?></td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td>
                                                <a href="mailto:<?php echo e($item->email); ?>" target="_blank"
                                                    class="btn btn-primary">Reply</a>
                                                <a href="<?php echo e(route('admin.delete-message', ['msg_id' => $item->id])); ?>"
                                                    class="btn btn-danger">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <hr class="my-3">
                <div class="card">
                    <div class="card-header">
                        <h5>Update Infomation</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.submit-contact')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row form-group">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email"
                                            value="<?php echo e($about->email); ?>" placeholder="Email">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" class="form-control" name="phone"
                                            value="<?php echo e($about->phone); ?>" placeholder="phone">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>City</label>
                                        <input type="text" class="form-control" name="city"
                                            value="<?php echo e($about->city); ?>" placeholder="City">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Website</label>
                                        <input type="text" class="form-control" name="website_link"
                                            value="<?php echo e($about->website_link); ?>" placeholder="Website Link">
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group float-end">
                                <button type="submit" class="btn btn-primary mr-2">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zamsh/zamsh.org/resources/views/admin/contact/view-contact.blade.php ENDPATH**/ ?>