<?php $__env->startSection('title', 'laraPortfolio - Edit Experience'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-3">
        <div class="card mt-4">
            <div class="card-header">
                <h4>Edit Experience <a href="<?php echo e(route('admin.create-exp')); ?>" class="btn btn-primary float-end">Create New
                        Experience</a></h4>
            </div>
            <div class="card-body">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Holy guacamole!</strong> <?php echo e(session('msg')); ?>

                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <form action="#" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="exp_id" value="<?php echo e($experience->id); ?>" hidden>
                            <div class="row form-group">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Experience Name</label>
                                        <input type="text" class="form-control" name="exp_name"
                                            value="<?php echo e($experience->experience_name); ?>">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['exp_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Start Date</label>
                                        <input type="month" class="form-control" name="start_date"
                                            value="<?php echo e($experience->start_date); ?>">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>End Date</label>
                                        <input type="month" class="form-control" name="end_date"
                                            value="<?php echo e($experience->end_date); ?>">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Short Description</label>
                                        <textarea class="form-control" name="short_desc" rows="2"><?php echo e($experience->short_desc); ?></textarea>
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['short_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Sort</label>
                                        <input type="number" class="form-control" name="sort"
                                            value="<?php echo e($experience->sort); ?>" placeholder="Sort by number">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control" name="status">
                                            <option value="Active" <?php echo e($experience->status == 'Active' ? 'selected' : ''); ?>>
                                                Active
                                            </option>
                                            <option value="Hidden"<?php echo e($experience->status == 'Hidden' ? 'selected' : ''); ?>>
                                                Hidden</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary mr-2">Update experience</button>
                                    <a href="<?php echo e(route('admin.create-exp')); ?>" class="btn btn-light">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>

                    <hr class="my-3">

                    <div class="col-12">
                        <div class="card-body">
                            <div class="table-responsive-md">
                                <table id="myTable" class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th>Experience Name</th>
                                            <th>Date</th>
                                            <th style="width: 40%;">Description</th>
                                            <th>Sort</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->experience_name); ?></td>
                                                <td><?php echo e($item->start_date); ?> - <?php echo e($item->end_date); ?></td>
                                                <td style="width: 40%;"><?php echo e($item->short_desc); ?></td>
                                                <td><?php echo e($item->sort); ?></td>
                                                <td><?php echo e($item->status); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.edit-exp', ['exp_id' => $item->id])); ?>"
                                                        class="btn btn-primary">Edit</a>

                                                    <?php if($item->id == $experience->id): ?>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('admin.delete-exp', ['exp_id' => $item->id])); ?>"
                                                            class="btn btn-danger">Delete</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zamsh/zamsh.org/resources/views/admin/experience/edit-exp.blade.php ENDPATH**/ ?>