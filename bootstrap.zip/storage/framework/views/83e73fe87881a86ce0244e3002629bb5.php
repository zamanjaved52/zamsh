<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; ZamSh <?php echo e(now()->year); ?></div>
            <div>
                Developed By
                &middot;
                <a href="https://www.facebook.com/itzAla71" target="_blank" style="text-decoration: none;">ZamSh</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/zamsh/zamsh.org/resources/views/layouts/inc/admin-footer.blade.php ENDPATH**/ ?>