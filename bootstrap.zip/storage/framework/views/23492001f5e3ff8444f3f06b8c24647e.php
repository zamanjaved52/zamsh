<?php $__env->startSection('title', 'laraPortfolio - Portfolio'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-3">
        <div class="card mt-4">
            <div class="card-header">
                <h4>Create Portfolio <a href="<?php echo e(route('public.index')); ?>" target="_blank"
                        class="btn btn-primary float-end">Live
                        View</a></h4>
            </div>
            <div class="card-body">
                <?php if(session('msg')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Holy guacamole!</strong> <?php echo e(session('msg')); ?>

                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <form action="<?php echo e(route('admin.create-portfolio')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row form-group">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Portfolio Name</label>
                                        <input type="text" class="form-control" name="portfolio_name"
                                            value="<?php echo e(old('portfolio_name')); ?>" placeholder="Modern Portfolio Website">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['portfolio_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Image (500 x 360)</label>
                                        <input type="file" class="form-control" name="portfolio_image"
                                            value="<?php echo e(old('portfolio_image')); ?>" placeholder="Recommended size: 500 x 360">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['portfolio_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Sort</label>
                                        <input type="number" class="form-control" name="sort"
                                            value="<?php echo e(old('sort')); ?>" placeholder="Sort by number">
                                        <p style="color:red;">
                                            <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                *<?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select class="form-control" name="status">
                                            <option value="Active" selected>Active
                                            </option>
                                            <option value="Hidden">Hidden</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary mr-2">Create Portfolio</button>
                                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-light">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>

                    <hr class="my-3">

                    <div class="col-12">
                        <div class="card-body">
                            <div class="table-responsive-md">
                                <table id="myTable" class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th>Portfolio Image</th>
                                            <th>Name</th>
                                            <th>Sort</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($item->portfolio_image == null): ?>
                                                        No Image
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('storage/portfolio')); ?>/<?php echo e($item->portfolio_image); ?>"
                                                            alt="admin avatar" style="height: 80px">
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($item->portfolio_name); ?></td>
                                                <td><?php echo e($item->sort); ?></td>
                                                <td><?php echo e($item->status); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.edit-portfolio', ['port_id' => $item->id])); ?>"
                                                        class="btn btn-primary">Edit</a>
                                                    <a href="<?php echo e(route('admin.delete-portfolio', ['port_id' => $item->id])); ?>"
                                                        class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zamsh/zamsh.org/resources/views/admin/portfolio/create-portfolio.blade.php ENDPATH**/ ?>