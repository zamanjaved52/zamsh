<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\laraPortfolio_laravel-project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>