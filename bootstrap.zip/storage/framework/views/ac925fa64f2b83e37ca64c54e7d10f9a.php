<?php $__env->startSection('title', 'ZamSh - Home'); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zamsh/zamsh.org/resources/views/public/index.blade.php ENDPATH**/ ?>