<!-- Services Section Start -->
<section class="service section" id="service">
    <div class="container">
        <div class="row">
            <div class="section-title padd-15">
                <h2>Services</h2>
            </div>
        </div>
        <div class="row">
            <?php if(count($services) != 0): ?>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Services item -->
                    <div class="service-item padd-15">
                        <div class="service-item-inner">
                            <div class="icon">
                                <i class="<?php echo e($item->icon_class); ?>"></i>
                            </div>
                            <h4><?php echo e($item->service_name); ?></h4>
                            <p>
                                <?php echo e($item->short_desc); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-mobile-alt"></i>
                        </div>
                        <h4>App Development</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-laptop-code"></i>
                        </div>
                        <h4>Web Development</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-palette"></i>
                        </div>
                        <h4>UI/UX Design</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-code"></i>
                        </div>
                        <h4>Web Design</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-search"></i>
                        </div>
                        <h4>SEO</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
                <!-- Services item -->
                <div class="service-item padd-15">
                    <div class="service-item-inner">
                        <div class="icon">
                            <i class="fa fa-bullhorn"></i>
                        </div>
                        <h4>Promotion</h4>
                        <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                            Blanditiis pariatur consectetur doloremque.
                        </p>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>
<!-- Services Section End -->
<?php /**PATH C:\laragon\www\laraPortfolio_laravel-project\resources\views/layouts/inc/public-main/service.blade.php ENDPATH**/ ?>