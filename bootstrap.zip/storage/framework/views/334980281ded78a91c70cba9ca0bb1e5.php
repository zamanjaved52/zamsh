<?php $__env->startSection('title', 'laraPortfolio - Logo & Favicon'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-3">
        <div class="card mt-4">
            <div class="card-header">
                <h4>Update Logo & Favicon <a href="<?php echo e(route('public.index')); ?>" target="_blank"
                        class="btn btn-primary float-end">Live View</a></h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="text-secondary">Previous</h4>
                                <h3 class="text-center mt-4 pb-4">
                                    <?php if($about): ?>
                                        <?php echo e($about->nickname); ?>

                                    <?php else: ?>
                                        Aamin
                                    <?php endif; ?>
                                </h3>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.logo-update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row form-group">
                                        <div class="form-group">
                                            <label>Nickname</label>
                                            <input type="text" class="form-control" name="nickname"
                                                value="<?php echo e($about ? $about->nickname : 'Aamin'); ?>" placeholder="Nickname">
                                            <p style="color:red;">
                                                <?php $__errorArgs = ['nickname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    *<?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="mt-4 mb-0">
                                        <div class="d-grid">
                                            <button type="submit" class="btn btn-primary btn-block">Generate/Update
                                                Logo</button>
                                        </div>
                                        <?php if(session('logo_msg')): ?>
                                            <div class="alert alert-success alert-dismissible fade show mt-3"
                                                role="alert">
                                                <strong>Holy guacamole!</strong> <?php echo e(session('logo_msg')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="text-secondary">Previous</h4>

                                <?php if($about): ?>
                                    <img class="rounded mx-auto d-block" width="80px" height="80px"
                                        src="<?php echo e(asset('storage/favicon')); ?>/<?php echo e($about->favicon); ?>" alt="favicon">
                                <?php else: ?>
                                    <img class="rounded mx-auto d-block" width="80px" height="80px"
                                        src="<?php echo e(asset('public-assets/images/fabicon.png')); ?>" alt="favicon">
                                <?php endif; ?>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('admin.fav-update')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="row form-group">
                                        <div class="form-group">
                                            <label>Favicon</label>
                                            <input type="file" class="form-control" name="favicon" placeholder="Favicon">
                                            <p style="color:red;">
                                                <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    *<?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="mt-4 mb-0">
                                        <div class="d-grid"><button type="submit" class="btn btn-primary btn-block">Update
                                                Favicon</button></div>
                                        <?php if(session('fav_msg')): ?>
                                            <div class="alert alert-success alert-dismissible fade show mt-3"
                                                role="alert">
                                                <strong>Holy guacamole!</strong> <?php echo e(session('fav_msg')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laraPortfolio_laravel-project\resources\views/admin/setting-control/logo-fav.blade.php ENDPATH**/ ?>