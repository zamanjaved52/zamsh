<!-- Home Section Start -->
<section class="home active section" id="home">
    <div class="container">
        <div class="row">
            <div class="home-info padd-15">
                <h3 class="hello">
                    Hello, My Name is <span class="name"><?php echo e($about ? $about->full_name : 'Zaman javed'); ?></span>
                </h3>
                <h3 class="my-profession">
                    I'm a <span class="typing"><?php echo e($about ? $about->designation : 'Web Developer'); ?></span>
                </h3>
                <p>
                    <?php echo $about
                        ? $about->short_description
                        : 'I&#39;m a web Development with extensive experience for over 5 years. My expertise is to create and design website, graphic design, and many more...'; ?>

                </p>
                <?php if($about): ?>
                    <a href="<?php echo e(asset('storage/cv_file/')); ?>/<?php echo e($about->cv_file); ?>" class="btn" download>Download
                        CV</a>
                <?php else: ?>
                    <a href="<?php echo e(asset('public-assets/cv_file.pdf')); ?>" class="btn" download>Download
                        CV</a>
                <?php endif; ?>
            </div>
            <div class="home-img padd-15">
                <?php if($about): ?>
                    <img src="<?php echo e(asset('storage/about_image/')); ?>/<?php echo e($about->image); ?>" alt="hero" />
                <?php else: ?>
                    <img src="<?php echo e(asset('public-assets/images/hero.jpg')); ?>" alt="hero" />
                <?php endif; ?>
            </div>
        </div>

        
        <div class="row padd-15">
            
            <?php if(session('msg')): ?>
                <div class="alert-box">
                    <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <strong>ZamSh!</strong> <?php echo e(session('msg')); ?>

                    </div>
                </div>
            <?php endif; ?>
            
            <?php if($errors->any()): ?>
                <div class="alert-box">
                    <div class="alert">
                        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span>
                        <strong>ZamSh!</strong> Message failed to send.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- Home Section End -->
<?php /**PATH /home/zamsh/zamsh.org/resources/views/layouts/inc/public-main/home.blade.php ENDPATH**/ ?>